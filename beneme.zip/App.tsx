import React from 'react';
import { HashRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Layout from './components/Layout';
import Hero from './components/Hero';
import EEGMonitor from './components/EEGMonitor';
import AICounselor from './components/AICounselor';
import MeditationGen from './components/MeditationGen';
import EducationCenter from './components/EducationCenter';
import { SERVICES } from './constants';
import { ArrowRight } from 'lucide-react';

const ServicesList: React.FC = () => (
  <div className="py-12 bg-slate-50">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center">
        <h2 className="text-base text-indigo-600 font-semibold tracking-wide uppercase">Our Services</h2>
        <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 sm:text-4xl">
          Comprehensive Neurological Care
        </p>
        <p className="mt-4 max-w-2xl text-xl text-slate-500 mx-auto">
          Explore our cutting-edge technology and therapeutic solutions designed to improve mental well-being.
        </p>
      </div>

      <div className="mt-10">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service) => (
            <div key={service.id} className="pt-6">
              <div className="flow-root bg-white rounded-lg px-6 pb-8 h-full border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                <div className="-mt-6">
                  <div>
                    <span className="inline-flex items-center justify-center p-3 bg-slate-50 rounded-md shadow-sm border border-slate-200">
                      {service.icon}
                    </span>
                  </div>
                  <h3 className="mt-8 text-lg font-medium text-slate-900 tracking-tight">{service.title}</h3>
                  <p className="mt-5 text-base text-slate-500">
                    {service.description}
                  </p>
                  <div className="mt-6">
                    <Link to={service.path} className="text-indigo-600 hover:text-indigo-500 font-medium flex items-center group">
                      Explore Service <ArrowRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <ServicesList />
            </>
          } />
          <Route path="/eeg" element={
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900">Live Neuro Monitor</h1>
                    <p className="text-slate-500 mt-2">View real-time physiological data streams and AI analysis.</p>
                </div>
                <EEGMonitor />
            </div>
          } />
          <Route path="/counseling" element={
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
                <div className="mb-8 text-center max-w-2xl mx-auto">
                    <h1 className="text-3xl font-bold text-slate-900">AI Counseling Center</h1>
                    <p className="text-slate-500 mt-2">A safe, private space to talk. Powered by advanced natural language processing.</p>
                </div>
                <AICounselor />
            </div>
          } />
          <Route path="/meditation" element={
             <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
                <div className="mb-8 text-center max-w-2xl mx-auto">
                    <h1 className="text-3xl font-bold text-slate-900">Generative Meditation</h1>
                    <p className="text-slate-500 mt-2">Create a mindfulness session tailored exactly to your current state of mind.</p>
                </div>
                <MeditationGen />
            </div>
          } />
          <Route path="/education" element={
            <EducationCenter />
          } />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;