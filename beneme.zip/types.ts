import React from 'react';

export enum ServiceType {
  EEG = 'EEG Monitoring',
  ECG = 'ECG Analysis',
  COUNSELING = 'AI Counseling',
  MEDITATION = 'Guided Meditation',
  AUDIO_THERAPY = 'Audio Therapy',
  CORTEX = 'Cortex Analysis',
  EDUCATION = 'Education Center'
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface EEGDataPoint {
  time: number;
  alpha: number;
  beta: number;
  theta: number;
  delta: number;
}

export interface MeditationConfig {
  mood: string;
  duration: string;
  focus: string;
}

export interface NavItem {
  label: string;
  path: string;
  icon?: React.ReactNode;
}