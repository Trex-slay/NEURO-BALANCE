import React, { useState, useEffect, useCallback, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Play, Pause, RefreshCw, Brain } from 'lucide-react';
import { EEGDataPoint } from '../types';
import { analyzeEEGData } from '../services/geminiService';

const EEGMonitor: React.FC = () => {
  const [data, setData] = useState<EEGDataPoint[]>([]);
  const [isPlaying, setIsPlaying] = useState(true);
  const [aiAnalysis, setAiAnalysis] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const intervalRef = useRef<number | null>(null);

  // Generate initial data
  useEffect(() => {
    const initialData: EEGDataPoint[] = [];
    for (let i = 0; i < 50; i++) {
      initialData.push(generateDataPoint(i));
    }
    setData(initialData);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const generateDataPoint = (time: number): EEGDataPoint => ({
    time,
    alpha: 40 + Math.random() * 20 + Math.sin(time * 0.1) * 10, // Relaxed state
    beta: 20 + Math.random() * 15 + Math.cos(time * 0.2) * 5,  // Active thinking
    theta: 10 + Math.random() * 10,                            // Drowsiness/meditation
    delta: 5 + Math.random() * 5,                              // Deep sleep
  });

  const updateData = useCallback(() => {
    setData((prevData) => {
      const lastTime = prevData.length > 0 ? prevData[prevData.length - 1].time : 0;
      const newPoint = generateDataPoint(lastTime + 1);
      const newData = [...prevData, newPoint];
      if (newData.length > 50) newData.shift(); // Keep window size constant
      return newData;
    });
  }, []);

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = window.setInterval(updateData, 200); // 5Hz update for smoothness
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying, updateData]);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    // Create a summary string of the last state
    const current = data[data.length - 1];
    const summary = `Alpha: ${current.alpha.toFixed(1)}, Beta: ${current.beta.toFixed(1)}, Theta: ${current.theta.toFixed(1)}, Delta: ${current.delta.toFixed(1)}`;
    
    const analysis = await analyzeEEGData(summary);
    setAiAnalysis(analysis);
    setIsAnalyzing(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <ActivityIcon className="text-indigo-600 animate-pulse" />
              Live EEG Monitor
            </h2>
            <p className="text-slate-500 text-sm">Real-time cortex activity visualization (Simulated)</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isPlaying 
                  ? 'bg-amber-100 text-amber-700 hover:bg-amber-200' 
                  : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
              }`}
            >
              {isPlaying ? <><Pause size={18} /> Pause</> : <><Play size={18} /> Resume</>}
            </button>
            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isAnalyzing ? <RefreshCw size={18} className="animate-spin" /> : <Brain size={18} />}
              Analyze State
            </button>
          </div>
        </div>

        <div className="h-[400px] w-full bg-slate-50 rounded-lg border border-slate-100 p-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="time" hide />
              <YAxis domain={[0, 80]} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0' }}
                itemStyle={{ fontSize: '12px' }}
              />
              <Legend verticalAlign="top" height={36} />
              <Line type="monotone" dataKey="alpha" stroke="#4f46e5" strokeWidth={2} dot={false} name="Alpha (Relaxation)" isAnimationActive={false} />
              <Line type="monotone" dataKey="beta" stroke="#ef4444" strokeWidth={2} dot={false} name="Beta (Focus)" isAnimationActive={false} />
              <Line type="monotone" dataKey="theta" stroke="#10b981" strokeWidth={2} dot={false} name="Theta (Creativity)" isAnimationActive={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* AI Insight Section */}
        {aiAnalysis && (
          <div className="mt-6 p-4 bg-indigo-50 border border-indigo-100 rounded-lg animate-fade-in">
            <div className="flex gap-3">
              <Brain className="w-6 h-6 text-indigo-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-indigo-900 mb-1">Gemini AI Insight</h3>
                <p className="text-indigo-800 leading-relaxed text-sm md:text-base">{aiAnalysis}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-semibold text-slate-700 mb-2">Alpha Waves</h3>
            <div className="text-3xl font-bold text-indigo-600">
                {data.length > 0 ? data[data.length-1].alpha.toFixed(1) : 0} <span className="text-sm font-normal text-slate-400">µV</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">Associated with relaxed wakefulness.</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-semibold text-slate-700 mb-2">Beta Waves</h3>
            <div className="text-3xl font-bold text-rose-500">
                {data.length > 0 ? data[data.length-1].beta.toFixed(1) : 0} <span className="text-sm font-normal text-slate-400">µV</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">Associated with active thinking and focus.</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-semibold text-slate-700 mb-2">Heart Rate Variability</h3>
            <div className="text-3xl font-bold text-emerald-500">
                {data.length > 0 ? (60 + data[data.length-1].theta).toFixed(0) : 0} <span className="text-sm font-normal text-slate-400">ms</span>
            </div>
             <p className="text-xs text-slate-500 mt-1">Derived from ECG sensor integration.</p>
        </div>
      </div>
    </div>
  );
};

// Helper component for icon
const ActivityIcon = ({ className }: { className?: string }) => (
  <svg className={`w-6 h-6 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);

export default EEGMonitor;