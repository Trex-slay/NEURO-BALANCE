import React, { useState } from 'react';
import { Mic, Music, Wind, CheckCircle } from 'lucide-react';
import { generateMeditationScript } from '../services/geminiService';
import { MeditationConfig } from '../types';

const MeditationGen: React.FC = () => {
  const [config, setConfig] = useState<MeditationConfig>({
    mood: '',
    duration: '5 minutes',
    focus: 'Relaxation'
  });
  const [script, setScript] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeStep, setActiveStep] = useState(0);

  const steps = ['Details', 'Generate', 'Meditate'];

  const handleGenerate = async () => {
    if (!config.mood) return;
    setActiveStep(1);
    setIsGenerating(true);
    const result = await generateMeditationScript(config);
    setScript(result);
    setIsGenerating(false);
    setActiveStep(2);
  };

  const reset = () => {
    setScript('');
    setActiveStep(0);
    setConfig({ ...config, mood: '' });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Progress Stepper */}
      <div className="flex justify-center">
        <div className="flex items-center space-x-4">
          {steps.map((step, idx) => (
            <div key={step} className="flex items-center">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 font-semibold text-sm
                ${idx <= activeStep ? 'border-purple-600 bg-purple-600 text-white' : 'border-slate-300 text-slate-400'}`}>
                {idx + 1}
              </div>
              <span className={`ml-2 text-sm font-medium ${idx <= activeStep ? 'text-purple-700' : 'text-slate-400'}`}>
                {step}
              </span>
              {idx < steps.length - 1 && (
                <div className={`w-8 h-0.5 mx-4 ${idx < activeStep ? 'bg-purple-600' : 'bg-slate-200'}`} />
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        
        {/* Controls */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 h-fit">
          <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-2">
            <Wind className="text-purple-500" />
            Customize Session
          </h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">How are you feeling right now?</label>
              <input
                type="text"
                value={config.mood}
                onChange={(e) => setConfig({ ...config, mood: e.target.value })}
                placeholder="e.g., Anxious, Tired, Overwhelmed, Happy..."
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Focus Area</label>
                <select
                  value={config.focus}
                  onChange={(e) => setConfig({ ...config, focus: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                >
                  <option>Relaxation</option>
                  <option>Focus & Clarity</option>
                  <option>Sleep</option>
                  <option>Anxiety Relief</option>
                  <option>Gratitude</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Duration</label>
                <select
                  value={config.duration}
                  onChange={(e) => setConfig({ ...config, duration: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                >
                  <option>2 minutes</option>
                  <option>5 minutes</option>
                  <option>10 minutes</option>
                  <option>15 minutes</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !config.mood}
              className="w-full py-4 bg-purple-600 text-white rounded-xl font-semibold shadow-lg shadow-purple-200 hover:bg-purple-700 disabled:opacity-50 disabled:shadow-none transition-all transform hover:-translate-y-0.5"
            >
              {isGenerating ? 'Designing Experience...' : 'Generate Meditation'}
            </button>
          </div>
        </div>

        {/* Output */}
        <div className="bg-slate-50 p-8 rounded-2xl border border-slate-200 relative overflow-hidden flex flex-col min-h-[500px]">
          {script ? (
            <>
              <div className="absolute top-0 right-0 p-4">
                <Music className="text-purple-200 w-24 h-24 opacity-20 transform rotate-12" />
              </div>
              <h3 className="text-xl font-serif font-medium text-purple-900 mb-6 relative z-10">Your Personal Session</h3>
              <div className="prose prose-purple overflow-y-auto pr-2 relative z-10 flex-grow scrollbar-hide">
                {script.split('\n').map((line, i) => (
                    line.trim() ? <p key={i} className="mb-4 text-slate-700 leading-relaxed text-lg">{line}</p> : <br key={i}/>
                ))}
              </div>
              <div className="mt-6 pt-6 border-t border-slate-200 flex justify-between items-center relative z-10">
                 <span className="text-sm text-slate-500">Read silently or imagine a voice.</span>
                 <button onClick={reset} className="text-purple-600 font-medium hover:text-purple-800">
                    Create New
                 </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-slate-400">
              <div className="w-20 h-20 bg-slate-200 rounded-full flex items-center justify-center mb-4">
                {isGenerating ? <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div> : <Mic className="w-10 h-10" />}
              </div>
              <p className="text-center max-w-xs">
                {isGenerating ? 'Consulting Gemini AI to craft your session...' : 'Enter your details to generate a unique guided meditation script.'}
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default MeditationGen;