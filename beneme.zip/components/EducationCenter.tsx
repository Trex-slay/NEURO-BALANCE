import React, { useState } from 'react';
import { BookOpen, Video, HelpCircle, ChevronDown, ChevronRight, Search, Sparkles } from 'lucide-react';
import { askEducationalQuestion } from '../services/geminiService';

interface ContentCategory {
  id: string;
  title: string;
  description: string;
  articles: Array<{ title: string; summary: string }>;
  faqs: Array<{ question: string; answer: string }>;
  videoTitle: string;
}

const CONTENT: Record<string, ContentCategory> = {
  eeg: {
    id: 'eeg',
    title: 'EEG & Neurofeedback',
    description: 'Understand how brainwaves work and how neurofeedback can train your brain for better performance.',
    articles: [
      { title: 'The 4 Major Brainwaves Explained', summary: 'Dive into Alpha, Beta, Theta, and Delta waves and what they mean for your daily life.' },
      { title: 'What is Neuroplasticity?', summary: 'Learn how your brain physically changes in response to learning and training.' },
      { title: 'Getting Started with Neurofeedback', summary: 'A beginner’s guide to your first session and what to expect.' },
    ],
    faqs: [
      { question: 'Is neurofeedback safe?', answer: 'Yes, neurofeedback is non-invasive. It simply measures brain activity and provides feedback; it does not input electricity into the brain.' },
      { question: 'How many sessions do I need?', answer: 'Results vary, but most users report noticeable changes after 10-20 sessions of consistent training.' },
    ],
    videoTitle: 'Introduction to EEG Technology'
  },
  ecg: {
    id: 'ecg',
    title: 'Biofeedback & ECG',
    description: 'Explore the connection between your heart rhythms, stress levels, and emotional state.',
    articles: [
      { title: 'Heart Rate Variability (HRV) 101', summary: 'Why a steady heart rate isn’t always good, and what high HRV tells us about resilience.' },
      { title: 'The Physiology of Stress', summary: 'How the fight-or-flight response affects your cardiovascular system.' },
    ],
    faqs: [
      { question: 'How does breathing affect my heart?', answer: 'Slow, deep breathing stimulates the vagus nerve, which can lower heart rate and increase HRV, promoting relaxation.' },
    ],
    videoTitle: 'Understanding HRV Biofeedback'
  },
  mindfulness: {
    id: 'mindfulness',
    title: 'Meditation & Audio Therapy',
    description: 'The science behind mindfulness practices and auditory stimulation for mental health.',
    articles: [
      { title: 'How Binaural Beats Work', summary: 'The science of auditory illusions and frequency following responses.' },
      { title: 'Mindfulness and the Prefrontal Cortex', summary: 'Scientific studies on how meditation thickens the brain regions associated with attention.' },
    ],
    faqs: [
      { question: 'Do I need headphones for audio therapy?', answer: 'Yes, especially for binaural beats, as they rely on delivering slightly different frequencies to each ear.' },
    ],
    videoTitle: 'Guided Meditation Techniques'
  },
  psychology: {
    id: 'psychology',
    title: 'Psychology & Counseling',
    description: 'Insights into cognitive behavioral therapy (CBT) and emotional well-being.',
    articles: [
      { title: 'Principles of CBT', summary: 'Identifying and challenging negative thought patterns.' },
      { title: 'When to Seek Professional Help', summary: 'Recognizing the signs of burnout, anxiety, and depression.' },
    ],
    faqs: [
      { question: 'Can AI replace a therapist?', answer: 'No. AI can offer immediate support and coping strategies, but it cannot replace the nuanced care and diagnosis provided by a licensed human professional.' },
    ],
    videoTitle: 'Basics of CBT'
  },
};

const EducationCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('eeg');
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);
  const [question, setQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState('');
  const [isAsking, setIsAsking] = useState(false);

  const activeContent = CONTENT[activeTab];

  const handleAskAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    
    setIsAsking(true);
    setAiAnswer('');
    const answer = await askEducationalQuestion(activeContent.title, question);
    setAiAnswer(answer);
    setIsAsking(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-slate-900">Knowledge Hub</h1>
        <p className="mt-4 text-slate-500 max-w-2xl mx-auto">
          Explore our library of educational resources to better understand your brain, body, and mind.
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        
        {/* Sidebar Navigation */}
        <div className="lg:w-1/4">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden sticky top-24">
            <div className="p-4 bg-slate-50 border-b border-slate-200">
              <h3 className="font-semibold text-slate-700">Categories</h3>
            </div>
            <nav className="flex flex-col">
              {Object.values(CONTENT).map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    setActiveTab(category.id);
                    setAiAnswer('');
                    setQuestion('');
                  }}
                  className={`flex items-center justify-between px-4 py-4 text-left transition-colors border-b border-slate-100 last:border-0 ${
                    activeTab === category.id
                      ? 'bg-indigo-50 text-indigo-700 border-l-4 border-l-indigo-600'
                      : 'text-slate-600 hover:bg-slate-50 border-l-4 border-l-transparent'
                  }`}
                >
                  <span className="font-medium">{category.title}</span>
                  {activeTab === category.id && <ChevronRight className="w-4 h-4" />}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="lg:w-3/4 space-y-8">
          
          {/* Ask AI Section */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
            <div className="flex items-start gap-4">
              <div className="bg-white/20 p-3 rounded-lg backdrop-blur-sm">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold mb-2">Ask Dr. Neuro about {activeContent.title}</h3>
                <p className="text-indigo-100 text-sm mb-4">Have a specific question? Get an instant, AI-generated explanation.</p>
                <form onSubmit={handleAskAI} className="relative">
                  <input
                    type="text"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    placeholder={`e.g., How does ${activeTab === 'eeg' ? 'neurofeedback' : activeTab === 'ecg' ? 'HRV' : 'it'} help with anxiety?`}
                    className="w-full px-4 py-3 pr-12 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-white/50"
                  />
                  <button 
                    type="submit" 
                    disabled={isAsking || !question}
                    className="absolute right-2 top-2 p-1 bg-indigo-500 rounded hover:bg-indigo-400 disabled:opacity-50 transition-colors"
                  >
                    <Search className="w-5 h-5 text-white" />
                  </button>
                </form>
                {isAsking && (
                   <div className="mt-4 text-sm text-indigo-100 animate-pulse">Consulting knowledge base...</div>
                )}
                {aiAnswer && (
                  <div className="mt-4 bg-white/10 rounded-lg p-4 backdrop-blur-md border border-white/20 animate-fade-in">
                    <p className="text-sm leading-relaxed">{aiAnswer}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Intro Section */}
          <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">{activeContent.title}</h2>
            <p className="text-slate-600 text-lg">{activeContent.description}</p>
          </div>

          {/* Video Section */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Video className="text-rose-500" /> Featured Video
            </h3>
            <div className="aspect-video bg-slate-900 rounded-lg flex items-center justify-center relative overflow-hidden group cursor-pointer">
               {/* Placeholder for real video embed */}
               <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 opacity-90"></div>
               <div className="relative z-10 text-center">
                 <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                    <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                 </div>
                 <h4 className="text-white font-medium">{activeContent.videoTitle}</h4>
                 <p className="text-slate-400 text-sm mt-1">Duration: 05:23</p>
               </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Articles */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <BookOpen className="text-emerald-500" /> Latest Articles
              </h3>
              <div className="space-y-4">
                {activeContent.articles.map((article, idx) => (
                  <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
                    <h4 className="font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">{article.title}</h4>
                    <p className="text-sm text-slate-500 mt-2 leading-relaxed">{article.summary}</p>
                    <div className="mt-3 text-xs font-medium text-indigo-600 flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                      Read Article <ChevronRight className="w-3 h-3 ml-1" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* FAQs */}
            <div className="space-y-4">
               <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <HelpCircle className="text-amber-500" /> Frequently Asked Questions
              </h3>
              <div className="space-y-2">
                {activeContent.faqs.map((faq, idx) => (
                  <div key={idx} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                    <button
                      onClick={() => setExpandedFaq(expandedFaq === `${idx}` ? null : `${idx}`)}
                      className="w-full px-5 py-4 text-left flex justify-between items-center hover:bg-slate-50 transition-colors"
                    >
                      <span className="font-medium text-slate-700 text-sm">{faq.question}</span>
                      <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${expandedFaq === `${idx}` ? 'rotate-180' : ''}`} />
                    </button>
                    {expandedFaq === `${idx}` && (
                      <div className="px-5 pb-4 pt-0 text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                        <div className="pt-3">{faq.answer}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default EducationCenter;