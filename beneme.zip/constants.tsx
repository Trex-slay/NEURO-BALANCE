import { Activity, Brain, Ear, HeartPulse, Mic, Smartphone, GraduationCap } from 'lucide-react';
import { ServiceType } from './types';

export const SERVICES = [
  {
    id: 'eeg',
    type: ServiceType.EEG,
    title: 'EEG Monitoring',
    description: 'Real-time Electroencephalography to track brain wave patterns and cognitive states.',
    icon: <Brain className="w-8 h-8 text-indigo-500" />,
    path: '/eeg'
  },
  {
    id: 'counseling',
    type: ServiceType.COUNSELING,
    title: 'AI Counseling',
    description: '24/7 empathetic psychological support and cognitive behavioral therapy assistance.',
    icon: <Smartphone className="w-8 h-8 text-emerald-500" />,
    path: '/counseling'
  },
  {
    id: 'meditation',
    type: ServiceType.MEDITATION,
    title: 'Guided Meditation',
    description: 'Personalized mindfulness sessions generated instantly based on your current mood.',
    icon: <Mic className="w-8 h-8 text-purple-500" />,
    path: '/meditation'
  },
  {
    id: 'education',
    type: ServiceType.EDUCATION,
    title: 'Education Center',
    description: 'Learn about neuroscience, biofeedback principles, and mental health strategies.',
    icon: <GraduationCap className="w-8 h-8 text-orange-500" />,
    path: '/education'
  },
  {
    id: 'ecg',
    type: ServiceType.ECG,
    title: 'ECG Analysis',
    description: 'Heart rhythm monitoring integrated with stress level detection algorithms.',
    icon: <HeartPulse className="w-8 h-8 text-rose-500" />,
    path: '/eeg' // Combined dashboard for demo
  },
  {
    id: 'audio',
    type: ServiceType.AUDIO_THERAPY,
    title: 'Audio Therapy',
    description: 'Binaural beats and iso-chronic tones designed to entrain brainwaves for focus or sleep.',
    icon: <Ear className="w-8 h-8 text-sky-500" />,
    path: '/meditation'
  },
  {
    id: 'cortex',
    type: ServiceType.CORTEX,
    title: 'Cortex Data',
    description: 'Deep dive analysis into cortical activity maps and neuroplasticity tracking.',
    icon: <Activity className="w-8 h-8 text-amber-500" />,
    path: '/eeg'
  }
];