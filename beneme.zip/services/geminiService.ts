import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { MeditationConfig } from "../types";

// Initialize the client. The API_KEY is injected by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const COUNSELOR_MODEL = 'gemini-3-flash-preview';
const MEDITATION_MODEL = 'gemini-3-flash-preview';
const ANALYST_MODEL = 'gemini-3-flash-preview';
const TUTOR_MODEL = 'gemini-3-flash-preview';

/**
 * Creates a chat session for the AI Counselor.
 */
export const createCounselorChat = (): Chat => {
  return ai.chats.create({
    model: COUNSELOR_MODEL,
    config: {
      systemInstruction: `You are Dr. Neuro, a compassionate, professional, and empathetic AI psychological counselor for Beneme. 
      Your goal is to listen to users, validate their feelings, and offer gentle, evidence-based coping strategies (CBT/Mindfulness). 
      ALWAYS include a disclaimer that you are an AI and not a replacement for emergency services if the user mentions self-harm or severe crisis. 
      Keep responses concise yet warm.`,
      temperature: 0.7,
    },
  });
};

/**
 * Sends a message to the chat session.
 */
export const sendChatMessage = async (chat: Chat, message: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text || "I apologize, I'm having trouble processing that right now.";
  } catch (error) {
    console.error("Chat Error:", error);
    return "I'm having a brief connection issue. Please try again in a moment.";
  }
};

/**
 * Generates a personalized meditation script.
 */
export const generateMeditationScript = async (config: MeditationConfig): Promise<string> => {
  try {
    const prompt = `Write a soothing, personalized guided meditation script.
    User's current mood: ${config.mood}.
    Desired focus: ${config.focus}.
    Duration style: ${config.duration} (keep the word count appropriate for this duration).
    
    Structure:
    1. Introduction (Deep breathing)
    2. Body Scan or Visualization (based on focus)
    3. Positive Affirmations
    4. Gentle Return
    
    Format: Use line breaks to indicate pauses. Do not include instructions like "[Pause for 5 seconds]", just write the spoken words.`;

    const response = await ai.models.generateContent({
      model: MEDITATION_MODEL,
      contents: prompt,
      config: {
        temperature: 0.8, // Slightly higher for creativity
      }
    });

    return response.text || "Breathe in... Breathe out... (Unable to generate script at this moment)";
  } catch (error) {
    console.error("Meditation Gen Error:", error);
    return "Breathe deeply. Focus on the present moment. (Service unavailable)";
  }
};

/**
 * Analyzes a snapshot of EEG data.
 */
export const analyzeEEGData = async (summary: string): Promise<string> => {
  try {
    const prompt = `Analyze this simulated EEG data summary for a neurofeedback user: "${summary}". 
    Briefly explain what this brainwave state suggests (e.g., Alpha for relaxation, Beta for focus) in simple terms and offer a quick tip to optimize their mental state.`;

    const response = await ai.models.generateContent({
      model: ANALYST_MODEL,
      contents: prompt,
    });

    return response.text || "Analysis incomplete.";
  } catch (error) {
    console.error("Analysis Error:", error);
    return "Could not analyze data at this time.";
  }
};

/**
 * Answers a specific educational question about a topic.
 */
export const askEducationalQuestion = async (topic: string, question: string): Promise<string> => {
  try {
    const prompt = `You are an expert tutor in neuroscience and psychology for the Beneme platform. 
    The user is browsing the "${topic}" section.
    
    Question: "${question}"
    
    Provide a clear, accurate, and beginner-friendly explanation. Keep it under 150 words.`;

    const response = await ai.models.generateContent({
      model: TUTOR_MODEL,
      contents: prompt,
    });

    return response.text || "I couldn't find an answer to that at the moment.";
  } catch (error) {
    console.error("Tutor Error:", error);
    return "Service temporarily unavailable.";
  }
};